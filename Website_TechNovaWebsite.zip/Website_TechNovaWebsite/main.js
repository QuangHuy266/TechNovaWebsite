document.addEventListener('DOMContentLoaded', () => {

  const enquiryForm = document.getElementById('enquiryForm');
  if (enquiryForm) {
    enquiryForm.addEventListener('submit', (e) => {
      e.preventDefault();
      handleEnquiry();
    });
  }

  const registerForm = document.getElementById('registerForm');
  if (registerForm) {
    registerForm.addEventListener('submit', (e) => {
      e.preventDefault();
      handleRegister();
    });
  }
});

function handleEnquiry() {
  const fullName = (document.getElementById('fullName') || {}).value?.trim() || '';
  const contactNumber = (document.getElementById('contactNumber') || {}).value?.trim() || '';
  const category = (document.getElementById('category') || {}).value?.trim() || '';
  const contactMethod = (document.querySelector('input[name="contactMethod"]:checked') || {}).value?.trim() || '';
  const message = (document.getElementById('message') || {}).value?.trim() || '';

  if (!fullName || !contactNumber || !category || !contactMethod || !message) {
    alert('Please fill in all required fields!');
    return;
  }

  const win = window.open('', '_blank', 'width=520,height=480');
  const safe = escapeHtml;
  const html = `
  <html><head><title>Submission</title></head><body style="font-family:Arial,Helvetica,sans-serif;padding:18px;color:#111">
    <h2 style="color:${getComputedStyle(document.documentElement).getPropertyValue('--brand') || '#007BFF'}">Congratulations..!!</h2>
    <p><strong>Name:</strong> ${safe(fullName)}</p>
    <p><strong>Contact Number:</strong> ${safe(contactNumber)}</p>
    <p><strong>Category of Enquiry:</strong> ${safe(category)}</p>
    <p><strong>Preferred Contact Method:</strong> ${safe(contactMethod)}</p>
    <p><strong>Message:</strong> ${safe(message)}</p>
  </body></html>`;
  win.document.write(html);
  win.document.close();
}

function handleRegister() {
  const name = (document.getElementById('rname') || {}).value?.trim() || '';
  const email = (document.getElementById('remail') || {}).value?.trim() || '';
  const pass = (document.getElementById('rpassword') || {}).value?.trim() || '';

  if (!name || !email || !pass) {
    alert('Please complete all registration fields.');
    return;
  }

  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!re.test(email) ) {
    alert('Invalid email address.');
    return;
  }

  alert('Registration successful! Welcome, ' + name + '.');
  const f = document.getElementById('registerForm');
  if (f) f.reset();
}

function escapeHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}